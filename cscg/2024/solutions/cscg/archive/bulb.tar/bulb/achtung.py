INFO:switch:Log file downloaded, removing old log
