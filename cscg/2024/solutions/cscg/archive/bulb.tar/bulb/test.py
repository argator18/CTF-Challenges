import requests
url = "https://e834e142617082b4a216a6e7-8000-bulb.challenge.cscg.live:1337/logs"
print(requests.get(url))
